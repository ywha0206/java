package ch07.sec03.exam1;

public class Phone {
	//필드선언
	public String model;
	public String color;
	
	//기본생성자선언
	public Phone() {
		System.out.println("Phone() 생성자 실행");
	}
}
