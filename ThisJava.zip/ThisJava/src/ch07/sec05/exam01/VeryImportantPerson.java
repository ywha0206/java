package ch07.sec05.exam01;

public class VeryImportantPerson extends Member{

}
