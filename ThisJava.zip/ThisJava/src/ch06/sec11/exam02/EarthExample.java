package ch06.sec11.exam02;

public class EarthExample {
	public static void main(String[] args) {
		//상수 읽기
		System.out.println("지구의 반지름: "+Earth.Earth_Radius+"km");
		System.out.println("지구의 표면적: "+Earth.Earth_Surface_Area + "km^2");
	}
}
