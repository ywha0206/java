package ch02.sec01;

public class VariableInitializationExample {
	public static void main(String[] args) {
		//변수 value 선언
//		int value;
//		
//		//연산결과를 변수 result 의 초기값으로 대입
//		int result = value + 10;
//		
//		//변수 result 값을 읽고 콘솔에 출력
//		System.out.println(result);
		
		// 초기화되지 않은 변수를 연산식에 사용할 경우 컴파일 에러가 난다
		// 변수에 최초로 값이 대입될 때 메모리에 할당되고 해당 메모리에 저장된다.
		// 이때 최초로 값을 대입하는 행위를 변수 초기화라고 함
	}
}
