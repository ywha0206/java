package ch01.sec10;
/*
 * @author 박연화
 */
/*
 * 장제목: 1장 자바 시작하기
 * 작성일: 2024.06.28
 */
public class Hello {
	//프로그램 실행 진입점
	public static void main(String[] args) {
		//콘솔에 출력하는 실행문
		System.out.println("Hello, Java");
	}
}
