package ch08.sec03;

public interface RemoteControl {
	int MAX_VALUME = 10;
	int MIN_VALUME = 0;
}
